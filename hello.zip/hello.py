def hello(name:str):
    return print(f"Hello, {name}!")
